#!/usr/bin/env bash

conda env create -f env.yml
conda activate cs224n_dfp